package com.capgemini.main;

import java.util.Scanner;

import com.capgemini.users.AdultUser;
import com.capgemini.users.KidUser;

public class LibraryInterfaceDemo {
	
	public static void main(String[] args) {
		int age;
		String bookType;
	
		
		Scanner scan = new Scanner(System.in);
		System.out.println("***********************Welcome to library Application:----************************");
		
		
	
		System.out.println("Enter Age :-- ");
		age = scan.nextInt();
		System.out.println("Enter BookType :-- ");
		bookType = scan.next();
		
		KidUser kd = new KidUser();
		kd.setAge(age);
		kd.registerAccount();
		kd.setBookType(bookType);
		kd.requestBook();
		
		AdultUser ad = new AdultUser();
		ad.setAge(age);
		ad.registerAccount();
		ad.setBookType(bookType);
		ad.requestBook();
		
	}

}
