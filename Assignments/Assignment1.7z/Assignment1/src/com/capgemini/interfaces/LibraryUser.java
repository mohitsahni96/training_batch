package com.capgemini.interfaces;

public interface LibraryUser {
	
	public void registerAccount();
	public void requestBook();
}
