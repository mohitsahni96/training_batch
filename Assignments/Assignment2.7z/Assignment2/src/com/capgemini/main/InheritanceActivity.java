package com.capgemini.main;

import com.capgemini.bean.Employee;
import com.capgemini.bean.Manager;
import com.capgemini.bean.Trainee;

public class InheritanceActivity {
	public static void main(String[] args) {
		System.out.println("***********Welcome to ABC Company Portal***************");
        System.out.println("\n");
		Manager manager = new Manager(126534, "Peter", "Chennai India", 237844, 65000);
		double salary = manager.calculateSalary();
		System.out.println("Manager's Salary is:- " + salary);

		double ta = manager.calculateTransportAllowance();
		System.out.println("TransportAllowance for manager is:- " + ta +" \n" +"Manager's Salary with transport allowance is:- "+(salary + ta));

		Trainee trainee = new Trainee(29846, "Jack", "Mumbai India", 442085, 45000);
		double salary2 = trainee.calculateSalary();
		System.out.println("Trainee's Salary is :- " + salary2);
		double ta2 = trainee.calculateTransportAllowance();
		System.out.println("TransportAllowance for trainee is:- " + ta2 +" \n" +"Trainee's Salary with transport allowance is:- "+(salary2 + ta2));

		
	}
	
	

}
