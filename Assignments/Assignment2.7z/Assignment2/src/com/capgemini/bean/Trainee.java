package com.capgemini.bean;

public class Trainee extends Employee{

	public Trainee()
	{
		super();
	}
	public Trainee(long id,String name,String addr,long phone,double salary)
	{
		super();
		this.employeeId = id;
		this.employeeName = name;
		this.employeeAddress = addr;
		this.emmployeePhone = phone;
		this.basicSalary = salary;
	}
}
