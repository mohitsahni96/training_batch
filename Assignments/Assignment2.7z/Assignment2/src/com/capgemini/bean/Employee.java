package com.capgemini.bean;

public class Employee{
	long employeeId;
	String employeeName;
	String employeeAddress;
	long emmployeePhone;
	double basicSalary;
	double specialAllowance = 250.80;
	double hra = 1000.50;
	
	public Employee()
	{
		super();
		//Default Constructor
		
	}
	public Employee(long id,String name,String addr,long phone,double salary)
	{
		super();
		this.employeeId = id;
		this.employeeName = name;
		this.employeeAddress = addr;
		this.emmployeePhone = phone;
		this.basicSalary = salary;
	}
	public double calculateSalary()
	{
		double salary2 = basicSalary + (basicSalary * specialAllowance / 100) + (basicSalary * hra / 100);
		return salary2;
		
	}
	public double calculateTransportAllowance()
	{
		double transportAllowance = (10 * basicSalary)/100;
		return transportAllowance;
		
	}

}
