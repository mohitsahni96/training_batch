package com.capgemini.library;

public abstract class MediaItem extends Item{
	
	private int runTime;


	MediaItem(int runTime)
	{
		this.runTime = runTime;
	}

	MediaItem(int uID, String title, int noOfCopies)
	{
		super(uID, title, noOfCopies);
	}

	MediaItem()
	{
		System.out.println("MediaItem constructor called ");
	}


	public void setRunTime(int runTime)
	{
		this.runTime = runTime;
	}

	public int getRunTime()
	{
	  return this.runTime;
	}

}
