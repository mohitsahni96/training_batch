package com.capgemini.library;

import java.util.Scanner;

public class Library {
	
	public static void main(String[] args) {
    
		System.out.println("**********************************Welcome to MyLibrary********************************************");
	    System.out.println("----------------------------------------------------------------------------------------------------");
	    Scanner scan = new Scanner(System.in);
	    
	    int choice = 0;
	    while(true)
	    {
	    System.out.println("1. Press 1 for Writtenitem");
	    System.out.println("2. Press 2 for MediaItem");
	    
	    choice = scan.nextInt();
	    
	    switch(choice)
	    {
	    case 1: System.out.println("Welcome to WrittenItem");
	            System.out.println("1. Press 1 for Journal");
	            System.out.println("2. Press 2 for Book");
	            int user = scan.nextInt();
	            switch(user)
	            {
	            case 1:
	           
	            int uid;
	            System.out.println("Enter uid :- ");
	            uid = scan.nextInt();
	            String title;
	            System.out.println("Enter title : --");
	            title = scan.next();
	            int numberOfCopies;
	            System.out.println("Enter NumberOfCopies :-- ");
	            numberOfCopies = scan.nextInt();
	            int yearOfPublication;
	            System.out.println("Enter Year Of Publication :-- ");
	            yearOfPublication = scan.nextInt();
	            Journal jl = new Journal(uid, title, numberOfCopies,yearOfPublication);
	           System.out.println(jl);
	            break;
	            
	            case 2:
	            
		            System.out.println("Enter uid :- ");
		            uid = scan.nextInt();
		            
		            System.out.println("Enter title : --");
		            title = scan.next();
		            
		            System.out.println("Enter NumberOfCopies: --");
		            numberOfCopies = scan.nextInt();
	            	
		            Book b = new Book(uid, title, numberOfCopies);
		            System.out.println(b);
	                break;
	            
	            }
	            break;
	            
	    case 2:  System.out.println("Welcome to MediaItem");
                 System.out.println("1. Press 1 for Video");
                 System.out.println("2. Press 2 for CD");
                 int ch = scan.nextInt();
                 switch(choice)
         	    {
         	    case 1:  

					System.out.println("Enter the uID: ");
					int uID = scan.nextInt();
					System.out.println("Enter the title: ");
					String title = scan.next();
					System.out.println("Enter the no. of Copies ");
					int noOfCopies = scan.nextInt();
					System.out.println("Enter the director name ");
					String directorName = scan.next();
					System.out.println("Enter the genre ");
					String genre = scan.next();
					System.out.println("Enter the year of release ");
					int yearOfRelease = scan.nextInt();

					Video video = new Video(uID, title, noOfCopies, directorName, genre, yearOfRelease);
		            System.out.println(video);
 
					break;
         	            case 2:
         	            	String artistName;
         	            	System.out.println("Enter the uID: ");
							uID = scan.nextInt();
							System.out.println("Enter the title: ");
							title = scan.next();
							System.out.println("Enter the no. of Copies ");
							noOfCopies = scan.nextInt();
							System.out.println("Enter the Artist name ");
							artistName = scan.next();
							System.out.println("Enter the genre ");
							genre = scan.next();
							CD cd = new CD(uID, title, noOfCopies, artistName, genre);
							System.out.println(cd);
         		            break;
         	            
    }
break;
	    }
	}
}
}
