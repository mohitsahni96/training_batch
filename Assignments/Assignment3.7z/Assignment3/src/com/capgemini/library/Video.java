package com.capgemini.library;

public  class Video extends MediaItem {
	private String directorName;
	private String genre;
	private int yearOfRelease;

	Video()
	{
		System.out.println("Video default constructor called");
	}

	

	Video(int uID, String title, int noOfCopies, String directorName, String genre, int yearOfRelease){
			
			super(uID, title, noOfCopies);
			this.directorName = directorName;
			this.genre = genre;
			this.yearOfRelease = yearOfRelease;
	}


	@Override
	public boolean checkIn(){

		System.out.println("Video check in called ");
		return true;
	}

	@Override
	public boolean checkOut(){
		System.out.println("Video check out called ");
		return true;
	}

	@Override 
	public void addItem(){

		System.out.println("Video add Item called ");
	}

	@Override
	boolean CheckIn() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	boolean Checkout() {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public String toString() {
		return "Video [  uid=" + uid + ", title=" + title + ", numberOfCopies=" + numberOfCopies +" directorName =" + directorName + ", genre=" + genre + ", yearOfRelease=" + yearOfRelease
				+"]";
	} 
	
}

