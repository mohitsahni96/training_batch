package com.capgemini.library;

public abstract class Item {
	public int uid;
	public String title;
	public int numberOfCopies;
	
	public Item()
	{
		super();
	}
	public Item(int uid, String title, int numberOfCopies)
	{
		super();
		this.uid = uid;
		this.title = title;
		this.numberOfCopies = numberOfCopies;
		
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getNumberOfCopies() {
		return numberOfCopies;
	}
	public void setNumberOfCopies(int numberOfCopies) {
		this.numberOfCopies = numberOfCopies;
	}
	
	@Override
	public String toString()
	{
		return String.format("UID : " +this.uid + "Title : "+ this.title + "NumberOfCopies : - " +this.numberOfCopies);
	}
	@Override
	public boolean equals(Object ob)
	{
		return true;
	}
	
	abstract boolean CheckIn();
	abstract boolean Checkout();
	abstract void addItem();
	
	public boolean checkIn() {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean checkOut() {
		// TODO Auto-generated method stub
		return false;
	}
}
