package com.capgemini.library;

public abstract class WrittenItem extends Item {
	private String authorName;
	private String authorEmailId;
	private String authorWebsite;
	
	public WrittenItem()
	{
		super();
	}
	
    WrittenItem(int uid, String title, int numberOfCopies)
	{
		super(uid, title, numberOfCopies);
	}
	
	public WrittenItem(String name, String email, String website)
	{
		super();
		this.authorName = name;
		this.authorEmailId = email;
		this.authorWebsite = website;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public String getAuthorEmailId() {
		return authorEmailId;
	}
	public void setAuthorEmailId(String authorEmailId) {
		this.authorEmailId = authorEmailId;
	}
	public String getAuthorWebsite() {
		return authorWebsite;
	}
	public void setAuthorWebsite(String authorWebsite) {
		this.authorWebsite = authorWebsite;
	}

}
