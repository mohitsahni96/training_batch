package com.capgemini.library;

public class Book extends WrittenItem {
	
	Book(int uid, String title, int numberOfCopies)
	{
		super(uid, title, numberOfCopies);
	}


	public boolean checkIn()
	{
		System.out.println("Book Check In Called!!!");
		return true;
	}
	public boolean checkOut()
	{
		System.out.println("Book Check Out called!!!");
		return true;
	}
	
	public void addItem()
	{
		System.out.println("Book addItem Called!!!");
	}
	
	@Override
	boolean CheckIn() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	boolean Checkout() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String toString() {
		return "Book [uid=" + uid + ", title=" + title + ", numberOfCopies=" + numberOfCopies + "]";
	}


}
