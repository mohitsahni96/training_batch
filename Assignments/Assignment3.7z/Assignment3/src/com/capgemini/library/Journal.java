package com.capgemini.library;

public class Journal extends WrittenItem {
	private int yearOfPublish;
	
	
    public Journal(int uid, String title, int numberOfCopies,int yearOfPublish)
	{
		super(uid, title, numberOfCopies);
		this.yearOfPublish = yearOfPublish;
	}

	public boolean checkIn()
	{
		System.out.println("Book Check In Called!!!");
		return true;
	}

	public boolean checkOut()
	{
		System.out.println("Book Check Out called!!!");
		return true;
	}
	

	@Override
	public String toString() {
		return "Journal [uid=" + uid + ", title=" + title + ", numberOfCopies=" + numberOfCopies +", yearOfPublish=" + yearOfPublish + "]";
	}

	public void addItem()
	{
		System.out.println("Book addItem Called!!!");
	}

	@Override
	boolean CheckIn() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	boolean Checkout() {
		// TODO Auto-generated method stub
		return false;
	}


}
