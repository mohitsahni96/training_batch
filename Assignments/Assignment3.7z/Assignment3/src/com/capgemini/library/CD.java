package com.capgemini.library;

public  class CD extends MediaItem{
	private String artistName;
	private String genre;

	CD()
	{
		System.out.println("CD default constructor called");
	}

	CD(int uID, String title, int noOfCopies, String artistName , String genre)
	{
		super(uID, title, noOfCopies);
		this.artistName = artistName;
		this.genre = genre;
	}
	
	

	

	

	@Override
	public String toString() {
		return "CD [artistName=" + artistName + ", genre=" + genre + ", uid=" + uid + ", title=" + title
				+ ", numberOfCopies=" + numberOfCopies + "]";
	}

	@Override
	public boolean checkIn(){

		System.out.println("CD check in called ");
		return true;
	}

	@Override
	public boolean checkOut(){

		System.out.println("CD check out called ");
		return true;
	}

	@Override 
	public void addItem(){

		System.out.println("CD add item called ");
	}

	@Override
	boolean CheckIn() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	boolean Checkout() {
		// TODO Auto-generated method stub
		return false;
	} 
	
}
