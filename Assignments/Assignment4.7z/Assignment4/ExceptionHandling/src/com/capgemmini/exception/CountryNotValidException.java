package com.capgemmini.exception;

public class CountryNotValidException extends Exception{
	public CountryNotValidException(String s) 
    { 
        // Call constructor of parent Exception 
        super(s); 
    } 
}
