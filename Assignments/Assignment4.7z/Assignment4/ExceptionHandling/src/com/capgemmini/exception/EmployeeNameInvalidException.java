package com.capgemmini.exception;

public class EmployeeNameInvalidException extends Exception
{
	public EmployeeNameInvalidException(String s) 
    { 
        super(s); 
    } 
}
