package com.capgemmini.exception;

public class TaxNotEligibleException extends Exception{
	
	public TaxNotEligibleException(String s) 
    { 
        super(s); 
    } 
}
