package com.capgemini.main;

import java.util.Scanner;

import com.capgemini.TaxCalculator;
import com.capgemmini.exception.CountryNotValidException;
import com.capgemmini.exception.EmployeeNameInvalidException;
import com.capgemmini.exception.TaxNotEligibleException;

public class CalculatorSimulator {
	static Scanner scan = new Scanner(System.in);

	static TaxCalculator taxCalculator = new TaxCalculator();
	
	static String empName, country = null;
	
	static double empSal, taxAmount = 0;

	public static void main(String[] args) 
	{
		System.out.println("Enter Employee name:- ");
		empName = scan.next();
		
		System.out.println("Enter salary:- ");
		empSal = scan.nextDouble();
		
		System.out.println("Is Country India? type(true/false):- ");
		country = scan.next();
		
		try {
			taxAmount = taxCalculator.calculateTax(empName, country, empSal);
			
			System.out.println("Total Tax Amount :- " + taxAmount);
			
		} catch (TaxNotEligibleException e) 
		{
			e.printStackTrace();
		} catch (EmployeeNameInvalidException e)
		{
			e.printStackTrace();
		} catch
		(CountryNotValidException e) 
		{
			e.printStackTrace();
		}
		finally {
			scan.close();
		}
	}
}
