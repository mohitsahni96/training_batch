package com.capgemini;

import java.util.Scanner;

import com.capgemmini.exception.CountryNotValidException;
import com.capgemmini.exception.EmployeeNameInvalidException;
import com.capgemmini.exception.TaxNotEligibleException;

public class TaxCalculator {
	
static TaxCalculator tc = new TaxCalculator();
	double taxAmount = 0;
	
	boolean res = false;
	
	
	public double calculateTax(String empName, String country, double empSal) throws TaxNotEligibleException, EmployeeNameInvalidException, CountryNotValidException 
	{
		if(tc.empNameCheck(empName, country, empSal)) 
		{
		if (empSal >= 100000)
			taxAmount = (empSal * 8) / 100;
		
		else if (empSal >= 50000 && empSal < 100000)
			taxAmount = (empSal * 6) / 100;
		
		else if (empSal >= 30000 && empSal < 50000)
			taxAmount = (empSal * 5) / 100;
		
		else if (empSal >= 10000 && empSal < 30000)
			taxAmount = (empSal * 4) / 100;
		
		else
			throw new TaxNotEligibleException("The Employee doesn't need to pay tax.");
		}
		
		return taxAmount;
	}

	//method to validate empty string
	public boolean empNameCheck(String empName, String country2, double empSal)
			throws EmployeeNameInvalidException, TaxNotEligibleException, CountryNotValidException {
		
		if (empName.isEmpty())
			throw new EmployeeNameInvalidException("Employee name cann't be Empty.");
		else {
			res =  tc.countryCheck(empName, country2, empSal);
		return res;
		}
	}

	//method to check if country is India or not
	private boolean countryCheck(String empName2, String country2, double empSal2)
			throws TaxNotEligibleException, CountryNotValidException 
	{
		if (country2.equalsIgnoreCase("true"))
{
			return true;
		}
		else {
			throw new CountryNotValidException("The Employee should be indian citizen to calculate tax.");
		}
	}
}